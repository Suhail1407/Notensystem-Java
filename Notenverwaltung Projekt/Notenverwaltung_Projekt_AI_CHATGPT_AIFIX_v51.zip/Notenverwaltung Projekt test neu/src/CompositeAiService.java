import java.util.List;

/**
 * Tries LIVE (OpenAI) if enabled. If it fails or returns empty output,
 * falls back to MOCK to guarantee an answer for demos/presentations.
 */
public class CompositeAiService implements AiService {

    private final OpenAiService live;
    private final MockAiService mock;
    private boolean webEnabled = true;

    public CompositeAiService(OpenAiService live, MockAiService mock) {
        this.live = live;
        this.mock = mock;
    }

    public boolean isLiveEnabled() {
        return live != null && live.isEnabled();
    }

    public void setWebEnabled(boolean enabled) {
        this.webEnabled = enabled;
        if (live != null) live.setWebSearchEnabled(enabled);
    }

    @Override
    public String explainTrend(StatsSnapshot stats) {
        String liveOut = null;
        if (isLiveEnabled()) liveOut = live.explainTrend(stats);
        if (isBad(liveOut)) return mock.explainTrend(stats);
        return liveOut;
    }

    @Override
    public String createStudyPlan(StatsSnapshot stats, String goal, int days) {
        String liveOut = null;
        if (isLiveEnabled()) liveOut = live.createStudyPlan(stats, goal, days);
        if (isBad(liveOut)) return mock.createStudyPlan(stats, goal, days);
        return liveOut;
    }

    @Override
    public String chat(StatsSnapshot stats, String userMessage, List<ChatTurn> history) {
        String liveOut = null;
        if (isLiveEnabled()) liveOut = live.chat(stats, userMessage, history);
        if (isBad(liveOut)) return mock.chat(stats, userMessage, history);
        return liveOut;
    }

    private boolean isBad(String s) {
        if (s == null) return true;
        String t = s.trim();
        if (t.isEmpty()) return true;
        String lower = t.toLowerCase();
        return lower.contains("live-fehler") || lower.contains("keine ausgabe") || lower.contains("error");
    }
}
