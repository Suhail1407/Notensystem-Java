import java.util.List;

public class MockAiService implements AiService {

    @Override
    public String explainTrend(StatsSnapshot stats) {
        StringBuilder sb = new StringBuilder();
        sb.append("Trend-Analyse (MOCK)\n\n");
        sb.append("Aktueller Stand\n");
        sb.append("- Gesamtschnitt: ").append(fmt(stats.overallAverage)).append("\n");
        sb.append("- Anzahl Noten: ").append(stats.totalCount).append("\n");
        sb.append("- Kritische Noten (>4.0): ").append(stats.criticalCount).append("\n");
        sb.append("- Schwaechstes Fach: ").append(stats.worstSubject).append("\n\n");

        sb.append("Interpretation\n");
        sb.append("- Skala 1.0 (best) bis 6.0 (schlecht).\n");
        sb.append("- Noten >4.0 verschlechtern den Schnitt ueberproportional.\n");
        sb.append("- Wenn du ").append(stats.worstSubject).append(" stabilisierst, verbessert sich der Gesamtschnitt am schnellsten.\n\n");

        sb.append("Naechste Schritte (5)\n");
        sb.append("1) 3x/Woche 25-35 Min Uebungen in ").append(stats.worstSubject).append(" + Fehlerliste.\n");
        sb.append("2) 1x/Woche Mini-Test (20-30 Min) + Nacharbeit.\n");
        sb.append("3) Vor jeder Leistung: 10 Min Wiederholung + 1 Beispielaufgabe.\n");
        sb.append("4) Pro Thema eine Mini-Zusammenfassung (5 Saetze).\n");
        sb.append("5) Jede Woche 1 Probeklausur/Altklausur-Block (30-45 Min).\n\n");

        sb.append("Rueckfrage: Wann ist die naechste Leistung und in welchem Fach?");
        return sb.toString();
    }

    @Override
    public String createStudyPlan(StatsSnapshot stats, String goal, int days) {
        StringBuilder sb = new StringBuilder();
        sb.append("Lernplan (MOCK)\n\n");
        sb.append("Ziel: ").append(goal).append("\n");
        sb.append("Zeitraum: ").append(days).append(" Tage\n\n");

        sb.append("Prioritaeten (Top 3)\n");
        int i = 1;
        for (String s : stats.topWeakSubjects(3)) sb.append(i++).append(") ").append(s).append("\n");
        sb.append("\n");

        sb.append("Wochenplan (wiederholbar)\n");
        sb.append("Mo: ").append(stats.worstSubject).append(" Uebungen (40 min) + 10 min Wiederholung\n");
        sb.append("Di: 20 min Karteikarten + 20 min Beispielaufgaben (2. Fach)\n");
        sb.append("Mi: ").append(stats.worstSubject).append(" Mini-Test (20 min) + Fehleranalyse (20 min)\n");
        sb.append("Do: 30 min Wiederholung (3. Fach) + 10 min Zusammenfassung\n");
        sb.append("Fr: Probeklausur/Altklausur (30-45 min)\n");
        sb.append("Sa: frei oder leicht (15 min Wiederholung)\n");
        sb.append("So: Wochenreview (15 min) + Planung\n\n");

        sb.append("Quick Wins\n");
        sb.append("- Fehlerliste fuehren (Thema -> Fehler -> Loesung)\n");
        sb.append("- Kurze, feste Einheiten (25-35 Min)\n");
        sb.append("- Jede Woche 1 Probetest im schwachen Fach\n\n");

        sb.append("Risiken\n");
        sb.append("- Unregelmaessigkeit ohne Routine\n");
        sb.append("- Zu wenig Uebungsaufgaben im schwachen Fach\n\n");

        sb.append("Rueckfrage: Wie viele Stunden pro Woche hast du realistisch?");
        return sb.toString();
    }

    @Override
    public String chat(StatsSnapshot stats, String userMessage, List<ChatTurn> history) {
        String msg = userMessage == null ? "" : userMessage.trim().toLowerCase();

        if (msg.contains("trend") || msg.contains("warum") || msg.contains("schnitt") || msg.contains("durchschnitt")) {
            return explainTrend(stats);
        }

        if (msg.contains("lernplan") || msg.contains("plan")) {
            int days = 30;
            try {
                String digits = msg.replaceAll("[^0-9]", " ").trim();
                if (!digits.isEmpty()) days = Integer.parseInt(digits.split("\\s+")[0]);
            } catch (Exception ignored) {}
            return createStudyPlan(stats, "Gesamtschnitt <= 2.5", days);
        }

        if (msg.contains("wie") && (msg.contains("verbesser") || msg.contains("besser"))) {
            StringBuilder sb = new StringBuilder();
            sb.append("So wuerde ich es konkret angehen:\n\n");
            sb.append("1) Fokus-Fach: ").append(stats.worstSubject).append("\n");
            sb.append("- 3 Einheiten/Woche: 10 min Wiederholung + 25 min Aufgaben + 5 min Fehlernotizen\n\n");
            sb.append("2) Kritische Noten abbauen (>4.0)\n");
            sb.append("- Jede Woche 1 Mini-Test + Fehleranalyse\n\n");
            sb.append("3) Stabilisierung der restlichen Faecher\n");
            sb.append("- 2 kurze Wiederholungen/Woche (20 min)\n\n");
            sb.append("Rueckfrage: Welches Thema ist im Fokus-Fach schwierig? (z.B. Formeln, Textaufgaben, Analysis)");
            return sb.toString();
        }

        return "Ich kann ausfuehrlich antworten. Beispiele:\n"
                + "- Warum ist mein Schnitt so?\n"
                + "- Erstelle einen Lernplan fuer 21/30 Tage mit Ziel 2.5\n"
                + "- Wie verbessere ich " + stats.worstSubject + "?\n";
    }

    private String fmt(double v) {
        if (Double.isNaN(v)) return "-";
        return String.format(java.util.Locale.US, "%.2f", v);
    }
}
