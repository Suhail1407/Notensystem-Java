public class AiServiceFactory {
    public static AiService create() {
        return new CompositeAiService(new OpenAiService(), new MockAiService());
    }
}
