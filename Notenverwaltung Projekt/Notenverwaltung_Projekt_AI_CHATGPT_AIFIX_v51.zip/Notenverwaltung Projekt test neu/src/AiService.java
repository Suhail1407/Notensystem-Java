import java.util.List;

public interface AiService {
    String explainTrend(StatsSnapshot stats);
    String createStudyPlan(StatsSnapshot stats, String goal, int days);
    String chat(StatsSnapshot stats, String userMessage, List<ChatTurn> history);
}
