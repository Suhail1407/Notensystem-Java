import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

/**
 * Minimal OpenAI client (no external libs). Uses Responses API.
 * Set OPENAI_API_KEY as environment variable.
 */
public class OpenAiService implements AiService {

    private final String apiKey;
    private final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(java.time.Duration.ofSeconds(20))
            .build();

    private boolean webSearchEnabled = true;

    public void setWebSearchEnabled(boolean enabled) {
        this.webSearchEnabled = enabled;
    }


    public OpenAiService() {
        this.apiKey = System.getenv("OPENAI_API_KEY");
        // Lightweight debug info (does NOT print the key itself)
        if (apiKey != null && !apiKey.isBlank()) {
            System.out.println("[OpenAiService] OPENAI_API_KEY erkannt (Länge): " + apiKey.length());
        }
    }

    public boolean isEnabled() {
        return apiKey != null && !apiKey.isBlank();
    }

    @Override
    public String explainTrend(StatsSnapshot stats) {
        String prompt =
                "SYSTEM: Du bist ein Lerncoach in einer Notenverwaltungs-App. " +
                "Antworte ausfuehrlich und gut lesbar. Nutze klare Ueberschriften und 10-14 Bulletpoints, wo passend. " +
                "Erfinde keine Daten. Notenskala: 1.0 (best) bis 6.0 (schlecht).\n\n" +
                "AUFGABE: Analysiere die Kennzahlen und erklaere Trends. Erklaere die Wirkung kritischer Noten (>4.0) " +
                "und welche Faecher den Schnitt treiben.\n" +
                "Nenne anschliessend 5 konkrete naechste Schritte (sofort umsetzbar) und 1 Rueckfrage.\n\n" +
                "KONTEXT (JSON):\n" + stats.toJson();
        return call(prompt);
    }

    @Override
    public String createStudyPlan(StatsSnapshot stats, String goal, int days) {
        String prompt =
                "SYSTEM: Du bist ein Lerncoach in einer Notenverwaltungs-App. Antworte ausfuehrlich und strukturiert. " +
                "Notenskala: 1.0 (best) bis 6.0 (schlecht).\n\n" +
                "AUFGABE: Erstelle einen Lernplan. Ziel: " + goal + ". Zeitraum: " + days + " Tage.\n" +
                "Output:\n1) Prioritaeten (Top 3 Faecher + Begruendung)\n2) Wochenplan (kurz)\n3) Quick Wins (3)\n4) Risiken (2)\n5) Rueckfrage\n\n" +
                "KONTEXT (JSON):\n" + stats.toJson();
        return call(prompt);
    }

    @Override
    public String chat(StatsSnapshot stats, String userMessage, List<ChatTurn> history) {
        StringBuilder sb = new StringBuilder();
        sb.append("SYSTEM: Du bist ein hilfreicher Lerncoach in einer Notenverwaltungs-App. ");
        sb.append("Antworte ausfuehrlich und gut lesbar. Nutze klare Ueberschriften und Bulletpoints. ");
        sb.append("Erfinde keine Daten. Stelle am Ende 1 Rueckfrage, falls Infos fehlen. ");
        sb.append("Notenskala: 1.0 (best) bis 6.0 (schlecht).\n\n");
        sb.append("KONTEXT (JSON):\n").append(stats.toJson()).append("\n\n");
        sb.append("VERLAUF:\n");
        if (history != null) {
            int start = Math.max(0, history.size() - 24);
            for (int i = start; i < history.size(); i++) {
                ChatTurn t = history.get(i);
                if (t == null) continue;
                sb.append((t.role == null ? "user" : t.role).toUpperCase()).append(": ")
                  .append(t.text == null ? "" : t.text).append("\n");
            }
        }
        sb.append("\nUSER: ").append(userMessage == null ? "" : userMessage).append("\nASSISTANT:");
        return call(sb.toString());
    }

    private String call(String prompt) {
        if (!isEnabled()) {
            return "LIVE-Fehler: OPENAI_API_KEY nicht gesetzt. Bitte Umgebungsvariable OPENAI_API_KEY setzen und IDE neu starten.";
        }

        String body = buildRequestBody(prompt);

        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create("https://api.openai.com/v1/responses"))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .timeout(java.time.Duration.ofSeconds(60))
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();

        try {
            HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString());
            int status = resp.statusCode();
            String raw = resp.body();

            // Print status + raw response on errors to make debugging straightforward.
            if (status >= 400) {
                System.out.println("[OpenAiService] HTTP Status: " + status);
                System.out.println("[OpenAiService] Response (raw, first 1200 chars):\n"
                        + (raw == null ? "" : raw.substring(0, Math.min(1200, raw.length()))));
                return "LIVE-Fehler: HTTP " + status + "\n" + safeSnippet(raw, 1200);
            }

            String out = extractText(raw);
            if (out == null) out = "";
            out = out.trim();

            // If web search is enabled, append sources (best-effort) from the raw JSON.
            if (webSearchEnabled) {
                String sources = extractUrls(raw);
                if (!sources.isBlank() && !out.contains("SOURCES")) {
                    out = out + sources;
                }
            }

            return out;
        } catch (Exception e) {
            // Print stack trace so you see the real cause in the console.
            e.printStackTrace();
            return "LIVE-Fehler: " + e.getClass().getSimpleName() + " - "
                    + (e.getMessage() == null ? "Unbekannter Fehler" : e.getMessage());
        }
    }

    private static String safeSnippet(String s, int maxChars) {
        if (s == null) return "";
        String trimmed = s.trim();
        if (trimmed.length() <= maxChars) return trimmed;
        return trimmed.substring(0, maxChars) + "...";
    }

    
    private String buildRequestBody(String prompt) {
        // If web search is enabled, allow model to use the built-in web_search tool.
        // See OpenAI docs: tools=[{type:"web_search"}] in Responses API.
        if (webSearchEnabled) {
            return "{"
                    + "\"model\":\"gpt-4.1-mini\","
                    + "\"tools\":[{\"type\":\"web_search\"}],"
                    + "\"tool_choice\":\"auto\","
                    + "\"input\":" + jsonString(prompt)
                    + "}";
        }
        return "{"
                + "\"model\":\"gpt-4.1-mini\","
                + "\"input\":" + jsonString(prompt)
                + "}";
    }

private static String jsonString(String s) {
        if (s == null) s = "";
        String escaped = s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
        return "\"" + escaped + "\"";
    }

    private static String extractText(String json) {
        if (json == null) return null;
        int idx = json.indexOf("\"output_text\"");
        if (idx >= 0) {
            int colon = json.indexOf(":", idx);
            int q = json.indexOf("\"", colon + 1);
            if (q >= 0) return readJsonString(json, q);
        }
        int t = json.indexOf("\"text\"");
        if (t < 0) return null;
        int colon = json.indexOf(":", t);
        int q = json.indexOf("\"", colon + 1);
        if (q < 0) return null;
        return readJsonString(json, q);
    }

    
    // Best-effort: extract up to 6 URLs from the raw JSON response (e.g. web_search annotations)
    private static String extractUrls(String json) {
        if (json == null) return "";
        java.util.LinkedHashSet<String> urls = new java.util.LinkedHashSet<>();
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(https?://[^\"\s]+)").matcher(json);
        while (m.find() && urls.size() < 6) {
            String u = m.group(1);
            // basic cleanup
            u = u.replace("\\u0026", "&");
            if (u.endsWith("\\")) u = u.substring(0, u.length()-1);
            urls.add(u);
        }
        if (urls.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        sb.append("\n\nSOURCES\n");
        for (String u : urls) sb.append("- ").append(u).append("\n");
        return sb.toString();
    }

private static String readJsonString(String json, int firstQuoteIndex) {
        int i = firstQuoteIndex + 1;
        StringBuilder sb = new StringBuilder();
        while (i < json.length()) {
            char c = json.charAt(i);
            if (c == '\\' && i + 1 < json.length()) {
                char n = json.charAt(i + 1);
                if (n == 'n') sb.append('\n');
                else if (n == 't') sb.append('\t');
                else if (n == 'r') sb.append('\r');
                else sb.append(n);
                i += 2;
                continue;
            }
            if (c == '"') break;
            sb.append(c);
            i++;
        }
        return sb.toString();
    }
}
