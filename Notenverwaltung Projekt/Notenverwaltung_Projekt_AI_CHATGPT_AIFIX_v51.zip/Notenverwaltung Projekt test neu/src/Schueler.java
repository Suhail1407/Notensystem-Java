/**
 * Die Klasse Schueler bildet einen einzelnen Schueler im Notensystem ab.
 * Jeder Schueler besitzt einen Namen und ein Alter, die beim Erstellen
 * des Objekts ueber den Konstruktor gesetzt werden.
 */
public class Schueler {

    // -------------------------
    // Attribute eines Schuelers
    // -------------------------

    /**
     * Der Name des Schuelers.
     * Dieses Attribut ist private, damit es nicht direkt von aussen veraendert werden kann.
     */
    private String name;

    /**
     * Das Alter des Schuelers in Jahren.
     * Auch dieses Attribut ist private, um die Daten zu schuetzen.
     */
    private int alter;


    // -------------------------
    // Konstruktor
    // -------------------------

    /**
     * Konstruktor zum Erstellen eines neuen Schueler-Objekts.
     * Beim Erzeugen muessen Name und Alter zwingend angegeben werden.
     *
     * @param name  Der Name des Schuelers
     * @param alter Das Alter des Schuelers
     */
    public Schueler(String name, int alter) {
        this.name = name;
        this.alter = alter;
    }


    // -------------------------
    // Getter-Methoden
    // -------------------------

    /**
     * Liefert den Namen des Schuelers zurueck.
     *
     * @return Name des Schuelers
     */
    public String getName() {
        return name;
    }

    /**
     * Liefert das Alter des Schuelers zurueck.
     *
     * @return Alter des Schuelers
     */
    public int getAlter() {
        return alter;
    }


    // -------------------------
    // Ausgabe-Methode
    // -------------------------

    /**
     * Ueberschreibt die Standard-Ausgabe eines Objekts
     * und liefert eine gut lesbare Darstellung eines Schuelers.
     *
     * Beispielausgabe:
     * "Ali (16 Jahre)"
     *
     * @return formatierter Text zum Schueler
     */
    @Override
    public String toString() {
        return name + " (" + alter + " Jahre)";
    }
}
