import java.util.ArrayList;
import java.util.List;

public class NotenVerwaltung {

    // 1. ArrayList<Note> notenListe
    private ArrayList<Note> notenListe;

    /**
     * Konstruktor zur Initialisierung der ArrayList.
     */
    public NotenVerwaltung() {
        this.notenListe = new ArrayList<>();
    }

    // 2. Methode: noteHinzufuegen(Note note)
    /**
     * Fuegt ein Note-Objekt zur internen Liste hinzu.
     * @param note Das hinzuzufuegende Note-Objekt.
     */
    public void noteHinzufuegen(Note note) {
        if (note != null) {
            this.notenListe.add(note);
            System.out.println("Note " + note.getWert() + " (" + note.getFach() + ") wurde hinzugefuegt.");
        }
    }

    // 3. Methode: durchschnittBerechnen()
    /**
     * Berechnet den arithmetischen Durchschnitt aller gespeicherten Noten.
     * @return Der berechnete Durchschnitt als double. 0.0, wenn keine Noten vorhanden sind.
     */
    public double durchschnittBerechnen() {
        if (notenListe.isEmpty()) {
            return 0.0; // Vermeidet Division durch Null
        }

        double summe = 0.0;
        for (Note note : notenListe) {
            summe += note.getWert();
        }

        return summe / notenListe.size();
    }

    // 4. Methode: getNoten()
    /**
     * Gibt die Liste aller gespeicherten Noten zurueck.
     * Hier verwenden wir List<Note> als Rueckgabetyp, was allgemeiner ist
     * und eine bessere Praxis darstellt (Programmier gegen Interfaces).
     * @return Eine (unveraenderliche) Liste der Note-Objekte.
     */
    public List<Note> getNoten() {
        // Wir geben eine Kopie der Liste oder besser ein Read-Only-View zurueck,
        // um die interne Liste vor unbeabsichtigten Aenderungen von aussen zu schuetzen.
        // Mit List.copyOf() (ab Java 10) oder Collections.unmodifiableList()
        // Wenn man die ArrayList direkt zurueckgibt, koennte externer Code die Liste veraendern,
        // was die Klasse NotenVerwaltung "kaputt" machen wuerde.
        // Fuers Studium ist aber oft auch die direkte Rueckgabe der ArrayList akzeptabel:
        
        // return this.notenListe; // Alternative, weniger sichere Variante

        return List.copyOf(this.notenListe); // Sicherere Variante (Java 9+)
    }
}