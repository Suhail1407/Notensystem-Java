public class ChatTurn {
    public final String role; // "user" or "assistant"
    public final String text;

    public ChatTurn(String role, String text) {
        this.role = role;
        this.text = text;
    }
}
