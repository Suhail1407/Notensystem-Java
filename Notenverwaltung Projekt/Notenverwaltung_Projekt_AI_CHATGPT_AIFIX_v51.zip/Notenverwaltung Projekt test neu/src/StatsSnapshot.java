import java.lang.reflect.Field;
import java.util.*;

/**
 * Snapshot with minimal, non-sensitive metrics derived from List<Note>.
 * Scale: 1.0 (best) to 6.0 (worst)
 */
public class StatsSnapshot {

    public final double overallAverage;
    public final int totalCount;
    public final int criticalCount; // > 4.0
    public final String worstSubject;

    private final Map<String, SubjectStats> bySubject;

    private StatsSnapshot(double overallAverage, int totalCount, int criticalCount, String worstSubject, Map<String, SubjectStats> bySubject) {
        this.overallAverage = overallAverage;
        this.totalCount = totalCount;
        this.criticalCount = criticalCount;
        this.worstSubject = worstSubject;
        this.bySubject = bySubject;
    }

    public static StatsSnapshot from(List<Note> notes) {
        if (notes == null) notes = Collections.emptyList();

        Field fFach = null;
        Field fWert = null;
        try {
            fFach = Note.class.getDeclaredField("fach");
            fWert = Note.class.getDeclaredField("wert");
            fFach.setAccessible(true);
            fWert.setAccessible(true);
        } catch (Exception ignored) { }

        Map<String, SubjectStats> map = new LinkedHashMap<>();
        double sum = 0.0;
        int count = 0;
        int critical = 0;

        for (Note n : notes) {
            try {
                Object fachObj = (fFach != null) ? fFach.get(n) : null;
                Object wertObj = (fWert != null) ? fWert.get(n) : null;

                String fachName = fachObj == null ? "Unbekannt" : fachObj.toString();
                double wert = (wertObj instanceof Number) ? ((Number) wertObj).doubleValue() : Double.NaN;
                if (Double.isNaN(wert)) continue;

                sum += wert;
                count++;
                if (wert > 4.0) critical++;

                SubjectStats s = map.computeIfAbsent(fachName, k -> new SubjectStats(k));
                s.add(wert);
            } catch (Exception ignored) { }
        }

        double avg = count == 0 ? Double.NaN : sum / count;

        String worst = "-";
        double worstAvg = -1;
        for (SubjectStats s : map.values()) {
            if (s.avg > worstAvg) {
                worstAvg = s.avg;
                worst = s.name;
            }
        }

        return new StatsSnapshot(avg, count, critical, worst, map);
    }

    public List<String> topWeakSubjects(int max) {
        List<SubjectStats> list = new ArrayList<>(bySubject.values());
        list.sort((a,b) -> Double.compare(b.avg, a.avg));
        List<String> out = new ArrayList<>();
        for (int i = 0; i < Math.min(max, list.size()); i++) {
            out.add(list.get(i).name + " ( " + String.format(Locale.US, "%.2f", list.get(i).avg) + ")");
        }
        if (out.isEmpty()) out.add("-");
        return out;
    }

    public String toJson() {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"scale\":{\"best\":1.0,\"worst\":6.0},");
        sb.append("\"overallAverage\":").append(Double.isNaN(overallAverage) ? "null" : String.format(Locale.US, "%.3f", overallAverage)).append(",");
        sb.append("\"totalCount\":").append(totalCount).append(",");
        sb.append("\"criticalCount\":").append(criticalCount).append(",");
        sb.append("\"worstSubject\":").append(jsonStr(worstSubject)).append(",");
        sb.append("\"subjects\":[");
        boolean first = true;
        for (SubjectStats s : bySubject.values()) {
            if (!first) sb.append(",");
            first = false;
            sb.append("{");
            sb.append("\"name\":").append(jsonStr(s.name)).append(",");
            sb.append("\"average\":").append(String.format(Locale.US, "%.3f", s.avg)).append(",");
            sb.append("\"count\":").append(s.count).append(",");
            sb.append("\"last\":").append(s.lastGradesJson());
            sb.append("}");
        }
        sb.append("]}");
        return sb.toString();
    }

    private static String jsonStr(String s) {
        if (s == null) return "\"\"";
        String escaped = s.replace("\\", "\\\\").replace("\"", "\\\"");
        return "\"" + escaped + "\"";
    }

    private static class SubjectStats {
        final String name;
        int count = 0;
        double sum = 0;
        double avg = Double.NaN;
        final Deque<Double> last = new ArrayDeque<>();

        SubjectStats(String name) { this.name = name; }

        void add(double v) {
            sum += v;
            count++;
            avg = sum / count;
            last.addLast(v);
            while (last.size() > 6) last.removeFirst();
        }

        String lastGradesJson() {
            StringBuilder sb = new StringBuilder();
            sb.append("[");
            boolean first = true;
            for (Double d : last) {
                if (!first) sb.append(",");
                first = false;
                sb.append(String.format(Locale.US, "%.2f", d));
            }
            sb.append("]");
            return sb.toString();
        }
    }
}
