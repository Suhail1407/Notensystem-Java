
public class ToastKind {

    public static final ToastKind INFO = null;
    public static ToastKind SUCCESS;

}
